import UIKit

struct carTypes {
    var enginetype1 = 180
    // Pretend name is "Vtype"
    var enginetype2 = 170
    // Pretend name is "Wtype"
    var enginetype3 = 190
    // Pretend name is "Radicaltype"
}

let myCarSelections = carTypes()

print("I have the option of choosing \(myCarSelections.enginetype2)")
print("I have the option of choosing \(myCarSelections.enginetype1)")
print("I have the option of choosing \(myCarSelections.enginetype3)")
